import React, { useState, useEffect } from 'react';
import Navbar from './components/Navbar';
import MealCard from './components/MealCard';
import Cart from './components/MyCart';

function Home() {
  const [searchTerm, setSearchTerm] = useState('');
  const [recipes, setRecipes] = useState([]);
  const [loading, setLoading] = useState(false);
  const [error, setError] = useState('');
  const [activePage, setActivePage] = useState('home'); // 'home' or 'cart'

  // LocalStorage থেকে কার্টের ডেটা লোড করা
  const [bookmarks, setBookmarks] = useState(() => {
    const saved = localStorage.getItem('recipeBookmarks');
    return saved ? JSON.parse(saved) : [];
  });

  // কার্ট আপডেট হলে LocalStorage-এ সেভ করা
  useEffect(() => {
    localStorage.setItem('recipeBookmarks', JSON.stringify(bookmarks));
  }, [bookmarks]);

  // API থেকে ডেটা আনার কমন ফাংশন
  const fetchRecipes = (query) => {
    setLoading(true);
    setError('');
    setRecipes([]);

    fetch(`https://www.themealdb.com/api/json/v1/1/search.php?s=${query}`)
      .then((res) => res.json())
      .then((data) => {
        setLoading(false);
        if (data.meals) {
          setRecipes(data.meals);
        } else {
          setError('No recipes found. Try searching for something else!');
        }
      })
      .catch(() => {
        setLoading(false);
        setError('Failed to fetch recipes. Check your internet connection.');
      });
  };

  // পেজ প্রথমবার লোড হলে ডিফল্ট ডেটা ('chicken') দেখাবে
  useEffect(() => {
    fetchRecipes('chicken');
  }, []);

  // সার্চ বাটনে ক্লিক করলে কল হবে
  const handleSearch = (e) => {
    e.preventDefault();
    if (!searchTerm.trim()) return;
    fetchRecipes(searchTerm);
  };

  // কার্টে অ্যাড বা রিমুভ করার ফাংশন
  const toggleBookmark = (recipe) => {
    const isBookmarked = bookmarks.some((item) => item.idMeal === recipe.idMeal);
    if (isBookmarked) {
      setBookmarks(bookmarks.filter((item) => item.idMeal !== recipe.idMeal));
    } else {
      setBookmarks([...bookmarks, recipe]);
    }
  };

  return (
    <div className="min-h-screen bg-gray-100 pb-10 font-sans">
      {/* Navbar Component */}
      <Navbar 
        cartCount={bookmarks.length} 
        activePage={activePage} 
        setActivePage={setActivePage} 
      />

      {/* পেজ সুইচিং: Home নাকি Cart */}
      {activePage === 'cart' ? (
        <Cart 
          bookmarks={bookmarks} 
          onToggleBookmark={toggleBookmark} 
          setActivePage={setActivePage} 
        />
      ) : (
        <div className="max-w-5xl mx-auto px-6">
          {/* Search Form */}
          <form onSubmit={handleSearch} className="flex gap-2 mb-8">
            <input
              type="text"
              placeholder="Search for a recipe (e.g., beef, pasta, cake)..."
              value={searchTerm}
              onChange={(e) => setSearchTerm(e.target.value)}
              className="flex-1 p-3 border rounded-lg shadow-sm focus:outline-none focus:ring-2 focus:ring-blue-500 bg-white"
            />
            <button
              type="submit"
              className="bg-blue-600 text-white px-6 py-3 rounded-lg font-semibold hover:bg-blue-700 transition"
            >
              Search
            </button>
          </form>

          {/* Loading & Error Messages */}
          {loading && <p className="text-center text-lg text-gray-600 py-10">Loading recipes...</p>}
          {error && <p className="text-center text-red-500 py-10">{error}</p>}

          {/* Recipe Grid using MealCard Component */}
          <div className="grid grid-cols-1 md:grid-cols-3 gap-6">
            {recipes.map((recipe) => {
              const isBookmarked = bookmarks.some((item) => item.idMeal === recipe.idMeal);
              return (
                <MealCard
                  key={recipe.idMeal}
                  recipe={recipe}
                  isBookmarked={isBookmarked}
                  onToggleBookmark={toggleBookmark}
                />
              );
            })}
          </div>
        </div>
      )}
    </div>
  );
}

export default Home;
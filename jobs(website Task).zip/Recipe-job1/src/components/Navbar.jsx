import React from 'react';

function Navbar({ cartCount, activePage, setActivePage }) {
  return (
    <nav className="bg-white shadow-md px-6 py-4 mb-6">
      <div className="max-w-5xl mx-auto flex justify-between items-center">
        {/* Logo / Title */}
        <h1 
          onClick={() => setActivePage('home')} 
          className="text-2xl font-bold text-blue-600 cursor-pointer"
        >
          🍳 Recipe Finder
        </h1>

        {/* Navigation Links */}
        <div className="space-x-4">
          <button
            onClick={() => setActivePage('home')}
            className={`px-4 py-2 rounded-lg font-semibold transition ${
              activePage === 'home' ? 'bg-blue-600 text-white' : 'text-gray-700 hover:bg-gray-100'
            }`}
          >
            Home
          </button>

          <button
            onClick={() => setActivePage('cart')}
            className={`px-4 py-2 rounded-lg font-semibold transition ${
              activePage === 'cart' ? 'bg-blue-600 text-white' : 'bg-gray-100 text-gray-800 hover:bg-gray-200'
            }`}
          >
            🛒 Cart ({cartCount})
          </button>
        </div>
      </div>
    </nav>
  );
}

export default Navbar;
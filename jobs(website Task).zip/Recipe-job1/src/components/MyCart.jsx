import React from 'react';
import MealCard from './MealCard';

function Cart({ bookmarks, onToggleBookmark, setActivePage }) {
  return (
    <div className="max-w-5xl mx-auto px-6">
      <div className="flex justify-between items-center mb-6">
        <h2 className="text-2xl font-bold text-gray-800">🛒 Your Saved Recipes ({bookmarks.length})</h2>
        <button
          onClick={() => setActivePage('home')}
          className="text-blue-600 font-semibold hover:underline"
        >
          ← Back to Home
        </button>
      </div>

      {bookmarks.length === 0 ? (
        <div className="text-center py-16 bg-white rounded-xl shadow-sm">
          <p className="text-gray-500 text-lg mb-4">Your cart is empty!</p>
          <button
            onClick={() => setActivePage('home')}
            className="bg-blue-600 text-white px-5 py-2 rounded-lg font-semibold"
          >
            Browse Recipes
          </button>
        </div>
      ) : (
        <div className="grid grid-cols-1 md:grid-cols-3 gap-6">
          {bookmarks.map((recipe) => (
            <MealCard
              key={recipe.idMeal}
              recipe={recipe}
              isBookmarked={true}
              onToggleBookmark={onToggleBookmark}
            />
          ))}
        </div>
      )}
    </div>
  );
}

export default Cart;
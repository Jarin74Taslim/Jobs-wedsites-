import React from 'react';

function MealCard({ recipe, isBookmarked, onToggleBookmark }) {
  return (
    <div className="bg-white rounded-xl shadow-md overflow-hidden flex flex-col">
      <img
        src={recipe.strMealThumb}
        alt={recipe.strMeal}
        className="w-full h-48 object-cover"
      />
      <div className="p-4 flex-1 flex flex-col justify-between">
        <div>
          <span className="text-xs bg-blue-100 text-blue-800 px-2 py-1 rounded font-semibold">
            {recipe.strCategory || 'General'}
          </span>
          <h3 className="text-lg font-bold text-gray-800 mt-2">{recipe.strMeal}</h3>
        </div>

        <div className="flex justify-between items-center mt-4">
          <a
            href={recipe.strSource || recipe.strYoutube}
            target="_blank"
            rel="noopener noreferrer"
            className="text-blue-600 text-sm font-semibold hover:underline"
          >
            View Details
          </a>
          <button
            onClick={() => onToggleBookmark(recipe)}
            className={`px-3 py-1.5 rounded-lg text-sm font-semibold transition ${
              isBookmarked
                ? 'bg-red-500 text-white hover:bg-red-600'
                : 'bg-green-600 text-white hover:bg-green-700'
            }`}
          >
            {isBookmarked ? 'Remove' : '+ Add to Cart'}
          </button>
        </div>
      </div>
    </div>
  );
}

export default MealCard;
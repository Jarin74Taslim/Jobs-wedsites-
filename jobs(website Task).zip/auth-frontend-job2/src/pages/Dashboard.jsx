import { useNavigate, Navigate } from 'react-router-dom';

function Dashboard() {
  const navigate = useNavigate();

  // ইউজার লগইন করা আছে কিনা চেক করা হচ্ছে
  const isAuthenticated = localStorage.getItem('isAuthenticated') === 'true';
  const savedUser = JSON.parse(localStorage.getItem('registerUser'));

  // লগইন করা না থাকলে সরাসরি Sign In পেজে পাঠিয়ে দেবে (Protected Route)
  if (!isAuthenticated) {
    return <Navigate to="/login" replace />;
  }

  // লগআউট ফাংশন
  const handleLogout = () => {
    localStorage.removeItem('isAuthenticated'); // লগইন স্ট্যাটাস মুছে ফেলা হলো
    navigate('/login', { replace: true }); // লগইন পেজে পাঠিয়ে দেওয়া হলো
  };

  return (
    // পুরো পেজের ব্যাকগ্রাউন্ড হালকা ধূসর (gray-100) এবং পুরো স্ক্রিন জুড়ে (min-h-screen) থাকবে
    <div className="min-h-screen bg-gray-100">
      
      {/* ১. উপরের নেভিগেশন বার (Navbar) */}
      <nav className="bg-white shadow-sm px-6 py-4 flex justify-between items-center">
        <h1 className="text-xl font-bold text-blue-600">MyDashboard</h1>
        
        {/* ডানপাশে ইউজারের নাম এবং লগআউট বাটন */}
        <div className="flex items-center gap-4">
          <span className="text-gray-600 text-sm hidden sm:block">
            Hi, {savedUser?.name}
          </span>
          <button 
            onClick={handleLogout} 
            className="bg-red-500 hover:bg-red-600 text-white text-sm font-medium px-4 py-2 rounded-lg transition cursor-pointer"
          >
            Logout
          </button>
        </div>
      </nav>

      {/* ২. ড্যাশবোর্ডের মেইন কন্টেন্ট বক্স (মাঝখানে থাকবে) */}
      <div className="max-w-3xl mx-auto mt-10 px-4">
        
        {/* ওয়েলকাম ব্যানার কার্ড */}
        <div className="bg-blue-600 text-white p-6 rounded-xl shadow-md mb-6">
          <h2 className="text-2xl font-bold">Welcome back, {savedUser?.name}! 👋</h2>
          <p className="text-blue-100 mt-1 text-sm">
            You are successfully logged into your personal dashboard.
          </p>
        </div>

        {/* ৩. ইউজারের প্রোফাইল ইনফরমেশন কার্ড */}
        <div className="bg-white p-6 rounded-xl shadow-sm border border-gray-200">
          <h3 className="text-lg font-semibold text-gray-800 border-b pb-3 mb-4">
            Profile Information
          </h3>

          {/* গ্রিড লেআউট: মোবাইলে ১ কলাম, বড় স্ক্রিনে ২ কলাম দেখাবে */}
          <div className="grid grid-cols-1 sm:grid-cols-2 gap-4">
            
            {/* নামের বক্স */}
            <div className="bg-gray-50 p-4 rounded-lg border border-gray-100">
              <p className="text-xs text-gray-400 uppercase font-semibold">Full Name</p>
              <p className="text-gray-800 font-medium mt-1">{savedUser?.name}</p>
            </div>

            {/* ইমেইলের বক্স */}
            <div className="bg-gray-50 p-4 rounded-lg border border-gray-100">
              <p className="text-xs text-gray-400 uppercase font-semibold">Email Address</p>
              <p className="text-gray-800 font-medium mt-1">{savedUser?.email}</p>
            </div>

            {/* অ্যাকাউন্ট স্ট্যাটাস বক্স */}
            <div className="bg-gray-50 p-4 rounded-lg border border-gray-100">
              <p className="text-xs text-gray-400 uppercase font-semibold">Account Status</p>
              <span className="inline-block mt-1 px-2.5 py-0.5 text-xs font-semibold bg-green-100 text-green-700 rounded-full">
                Active
              </span>
            </div>

          </div>
        </div>

      </div>
    </div>
  );
}

export default Dashboard;
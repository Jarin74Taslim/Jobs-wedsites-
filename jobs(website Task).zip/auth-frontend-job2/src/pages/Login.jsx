// React থেকে useState এবং useEffect হুক ইমপোর্ট করা হচ্ছে
import { useState, useEffect } from 'react';
import { useNavigate, Link } from 'react-router-dom';

function Login() {
  const [email, setEmail] = useState('');
  const [password, setPassword] = useState('');
  const [error, setError] = useState('');

  const navigate = useNavigate();

  // পেজটি লোড হওয়ার সাথে সাথেই এই useEffect কাজ করবে
  useEffect(() => {
    // localStorage থেকে চেক করা হচ্ছে ইউজার আগে থেকেই লগইন করা আছে কিনা
    const isAuth = localStorage.getItem('isAuthenticated');

    // যদি 'isAuthenticated' এর মান 'true' থাকে, তবে Login পেজে না রেখে সরাসরি ড্যাশবোর্ডে পাঠিয়ে দেবে
    if (isAuth === 'true') {
      navigate('/dashboard', { replace: true }); // replace: true দিলে ব্রাউজারের Back বাটন চাপলেও আর লগইন পেজে ফিরবে না
    }
  }, [navigate]);

  const handleLogin = (e) => {
    e.preventDefault();

    // ইউজারের ইনপুট দেওয়া ইমেইল থেকে বাড়তি স্পেস কেটে ছোট হাতের (lowercase) করা হচ্ছে
    const cleanEmail = email.trim().toLowerCase();

    // ১. খালি ফিল্ড এবং ভ্যালিড ইমেইল ফরম্যাট চেক
    if (!cleanEmail || !cleanEmail.includes('@') || !cleanEmail.includes('.')) {
      return setError('Please enter a valid email address!');
    }

    // ২. মিনিমাম পাসওয়ার্ড লেন্থ চেক
    if (password.length < 6) {
      return setError('Password must be at least 6 characters!');
    }

    // localStorage থেকে সেভ করা ইউজার আনা
    const savedUser = JSON.parse(localStorage.getItem('registerUser'));

    if (!savedUser) {
      return setError('No account found! Please Sign Up first.');
    }

    // ৩. ছোট হাতের ইমেইল (cleanEmail) এবং পাসওয়ার্ড ম্যাচিং চেক
    if (savedUser.email === cleanEmail && savedUser.password === password) {
      localStorage.setItem('isAuthenticated', 'true'); // লগইন স্ট্যাটাস সেভ
      navigate('/dashboard', { replace: true }); // ড্যাশবোর্ডে নিয়ে যাবে
    } else {
      setError('Invalid email or password!');
    }
  };

  return (
    <div className="card-box">
      <h2>Sign In</h2>
      {error && <p className="error-msg">{error}</p>}

      <form onSubmit={handleLogin}>
        <div className="form-group">
          <label>Email</label>
          <input
            type="text"
            placeholder="Enter your email"
            value={email}
            onChange={(e) => setEmail(e.target.value)}
          />
        </div>

        <div className="form-group">
          <label>Password</label>
          <input
            type="password"
            placeholder="Enter your password"
            value={password}
            onChange={(e) => setPassword(e.target.value)}
          />
        </div>

        <button type="submit" className="btn">Login</button>
      </form>

      {/* Sign Up পেজে যাওয়ার লিংক */}
      <p className="switch-link">
        Don't have an account? <Link to="/signup">Sign Up</Link>
      </p>
    </div>
  );
}

export default Login;
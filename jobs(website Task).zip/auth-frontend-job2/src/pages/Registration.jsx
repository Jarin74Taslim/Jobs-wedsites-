// React থেকে useState হুক ইমপোর্ট করা হচ্ছে (ইনপুট ফিল্ডের ডেটা ধরে রাখার জন্য)
import { useState } from "react";

// সুন্দর নোটিফিকেশন বা পপ-আপ মেসেজ দেখানোর জন্য toast ইমপোর্ট করা হচ্ছে
import toast from "react-hot-toast";

// এক পেজ থেকে অন্য পেজে যাওয়ার জন্য Link এবং useNavigate ইমপোর্ট করা হচ্ছে
import { Link, useNavigate } from "react-router-dom";

// Signup নামে একটি ফাংশনাল কম্পোনেন্ট তৈরি করা হলো
function Signup() {
    // ইউজারের ইনপুটগুলো জমা রাখার জন্য আলাদা আলাদা state তৈরি করা হলো (শুরুতে সব খালি '' থাকবে)
    const [name, setName] = useState(''); // নাম রাখার জন্য
    const [email, setEmail] = useState(''); // ইমেইল রাখার জন্য
    const [password, setPassword] = useState(''); // পাসওয়ার্ড রাখার জন্য
    const [confirmPassword, setConfirmPassword] = useState(''); // কনফার্ম পাসওয়ার্ড রাখার জন্য
    const [error, setError] = useState(''); // কোনো ভুল (error) হলে সেই মেসেজ দেখানোর জন্য

    // ফর্ম সাবমিট সফল হলে অন্য পেজে পাঠানোর জন্য navigate ফাংশনটি নেওয়া হলো
    const navigate = useNavigate();

    // ফর্ম সাবমিট (Register বাটনে ক্লিক) করলে এই ফাংশনটি কাজ করবে
    const handleSignup = (e) => {
        // ফর্ম সাবমিট হলে ব্রাউজার যেন রিলোড না হয়, তা বন্ধ করার জন্য
        e.preventDefault();

        // ইউজারের নাম ও ইমেইল থেকে বাড়তি স্পেস কাটা হচ্ছে এবং ইমেইলকে ছোট হাতের (lowercase) করা হচ্ছে
        const cleanName = name.trim();
        const cleanEmail = email.trim().toLowerCase(); // ক্যাপিটাল লেটার লিখলেও অটোমেটিক ছোট হাতের হয়ে যাবে
         
        // ১. চেক করা হচ্ছে নামের ঘর খালি কিনা
        if (cleanName === "") {
            alert("name is required"); // ব্রাউজারে অ্যালার্ট দেখাবে
            return setError("name is required"); // error স্টেটে মেসেজ সেট করে এখানেই ফাংশন থামিয়ে দেবে
        }

        // ২. চেক করা হচ্ছে ইমেইলের ঘর খালি কিনা
        if (cleanEmail === "") {
            alert("email is required");
            return setError("email is required");
        }

        // ৩. ইমেইল সঠিক ফরম্যাটে (@ এবং . আছে কিনা) তা চেক করা হচ্ছে
        if (!cleanEmail.includes("@") || !cleanEmail.includes(".")) {
            alert("use valid email");
            return setError("use valid email");
        }

        // ৪. চেক করা হচ্ছে পাসওয়ার্ড ৬ অক্ষরের কম কিনা
        if (password.length < 6) {
            alert("password must be 6 letter");
            return setError("password must be 6 letter");
        }

        // ৫. পাসওয়ার্ড এবং কনফার্ম পাসওয়ার্ড একই কিনা তা চেক করা হচ্ছে
        if (password !== confirmPassword) {
            return setError("password not match"); // না মিললে এরর দেখাবে
        }

        // সব ভ্যালিডেশন ঠিক থাকলে এরর মেসেজ খালি করে দেওয়া হলো
        setError("");

        // ইউজারের পরিষ্কার নাম, ছোট হাতের ইমেইল ও পাসওয়ার্ড দিয়ে একটি অবজেক্ট তৈরি করা হলো
        const userData = { 
            name: cleanName, 
            email: cleanEmail, // সবসময় ছোট হাতের ইমেইল সেভ হবে
            password 
        };

        // ব্রাউজারের localStorage-এ ইউজারের ডেটা সেভ করা হচ্ছে (অবজেক্টকে স্ট্রিং বানিয়ে সেভ করতে হয়)
        localStorage.setItem("registerUser", JSON.stringify(userData));
    
        // রেজিস্ট্রেশন সফল হয়েছে এমন একটি সবুজ টোস্ট (নোটিফিকেশন) দেখাবে
        toast.success("registration successful");

        // সবশেষে ইউজারকে লগইন (login) পেজে নিয়ে যাবে
        navigate("/login");
    }

    // এখান থেকে স্ক্রিনে যা দেখা যাবে (UI / JSX) তা রিটার্ন করা হচ্ছে
    return (
        // পুরো ফর্মের মেইন বক্স
        <div className="card-box">
            <h2>Sign Up</h2>
            
            {/* যদি error স্টেটে কোনো মেসেজ থাকে, তবে তা লাল রঙে দেখাবে, আর না থাকলে কিছু দেখাবে না */}
            {error ? <p className="text-red-500">{error}</p> : ""}

            {/* ফর্ম শুরু: সাবমিট করলে handleSignup ফাংশনটি কল হবে */}
            <form onSubmit={handleSignup}>

                {/* ফুল নেম (Full Name) ইনপুট ফিল্ড */}
                <div className="form-group">
                    <label>Full Name</label>
                    <input
                        type="text"
                        placeholder="Enter your name"
                        value={name} // ইনপুটের মান name স্টেট থেকে আসবে
                        onChange={(e) => setName(e.target.value)} // ইউজার কিছু টাইপ করলে তা name স্টেটে আপডেট হবে
                    />
                </div>

                {/* ইমেইল (Email) ইনপুট ফিল্ড */}
                <div className="form-group">
                    <label>Email</label>
                    <input
                        type="text"
                        placeholder="Enter your email"
                        value={email} // ইনপুটের মান email স্টেট থেকে আসবে
                        onChange={(e) => setEmail(e.target.value)} // টাইপ করার সাথে সাথে email স্টেট আপডেট হবে
                    />
                </div>

                {/* পাসওয়ার্ড (Password) ইনপুট ফিল্ড */}
                <div className="form-group">
                    <label>Password</label>
                    <input
                        type="password" // type="password" দেওয়ার কারণে লেখাগুলো ডট (•••) আকারে দেখাবে
                        placeholder="Minimum 6 characters"
                        value={password}
                        onChange={(e) => setPassword(e.target.value)}
                    />
                </div>

                {/* কনফার্ম পাসওয়ার্ড (Confirm Password) ইনপুট ফিল্ড */}
                <div className="form-group">
                    <label>Confirm Password</label>
                    <input
                        type="password"
                        placeholder="Re-type your password"
                        value={confirmPassword}
                        onChange={(e) => setConfirmPassword(e.target.value)}
                    />
                </div>

                {/* ফর্ম সাবমিট করার বাটন */}
                <button type="submit" className="btn">Register</button>
            </form>

            {/* যাদের আগে থেকেই অ্যাকাউন্ট আছে, তাদের লগইন পেজে যাওয়ার লিংক */}
            <p className="switch-link">
                Already have an account? <Link to="/login">Sign In</Link>
            </p>
        </div>
    );
}

// অন্য ফাইলে এই Signup কম্পোনেন্টটি ব্যবহার করার জন্য এক্সপোর্ট করা হলো
export default Signup;